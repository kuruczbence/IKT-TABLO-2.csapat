# IKT-TABLO-2.csapat
Lattmann Erik, Lázár Tomi, Kurucz Bence

Lázár Tamás forrásai:
https://en.wikipedia.org/wiki/SpongeBob_SquarePants
https://en.wikipedia.org/wiki/List_of_SpongeBob_SquarePants_characters
https://spongebob.fandom.com/wiki/SpongeBob_SquarePants_(series)
